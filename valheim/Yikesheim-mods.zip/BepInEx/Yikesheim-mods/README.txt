Yikesheim mod pack (Big Yikes guild Valheim server)
https://yikesgaming.com/valheim/

Unmodified releases of the following, repackaged for one-step install:

- BepInExPack for Valheim 5.4.2351 (denikson). BepInEx is licensed under LGPL-2.1.
  Source: https://github.com/BepInEx/BepInEx  Package: https://thunderstore.io/c/valheim/p/denikson/BepInExPack_Valheim/
- Valheim Plus 10.2.0 (Grantapher fork). Licensed under AGPL-3.0.
  Source: https://github.com/Grantapher/ValheimPlus  Package: https://thunderstore.io/c/valheim/p/Grantapher/ValheimPlus_Grantapher_Temporary/
- Runic Character Vault 1.0.3 (Chazman). MIT License, see RunicCharacterVault-LICENSE.txt and -NOTICE.md.
  Source: https://github.com/ChazmanMods/ValheimMods  Package: https://thunderstore.io/c/valheim/p/Chazman/RunicCharacterVault/
  The only change: three join messages in Translations/RunicCharacterVault/English.json are reworded for Yikesheim.

To turn the mods off, rename winhttp.dll in your Valheim folder to winhttp.dll.off.
