# Credits

Runic Character Vault is based on [Landoria CharacterVault](https://github.com/landoria-gaming/LandoriaMods/tree/main/Landoria.CharacterVault).

Original copyright: Copyright (c) 2026 End3rbyte.

The original work is licensed under the MIT License included in this package. Runic adaptations by Chazman.
